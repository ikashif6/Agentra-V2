(function () {
  'use strict';

  var cfg = window.agentraCookieConsent || {};
  var i18n = cfg.i18n || {};
  var COOKIE_NAME = cfg.cookieName || 'agentra_cookie_consent';
  var CONSENT_DAYS = Number(cfg.consentDays || 180);
  var VERSION = cfg.version || '1';

  var root = null;
  var els = {};
  var state = {
    necessary: true,
    functional: false,
    analytics: false,
    marketing: false,
  };

  function $(sel, parent) {
    return (parent || document).querySelector(sel);
  }

  function readCookie(name) {
    var match = document.cookie.match(new RegExp('(?:^|; )' + name.replace(/([.$?*|{}()[\]\\/+^])/g, '\\$1') + '=([^;]*)'));
    return match ? decodeURIComponent(match[1]) : null;
  }

  function writeCookie(name, value, days) {
    var maxAge = Math.max(1, days) * 24 * 60 * 60;
    var secure = location.protocol === 'https:' ? '; Secure' : '';
    document.cookie =
      name +
      '=' +
      encodeURIComponent(value) +
      '; Path=/; Max-Age=' +
      maxAge +
      '; SameSite=Lax' +
      secure;
  }

  function parseConsent(raw) {
    if (!raw) return null;
    try {
      var data = JSON.parse(raw);
      if (!data || typeof data !== 'object') return null;
      return {
        necessary: true,
        functional: !!data.functional,
        analytics: !!data.analytics,
        marketing: !!data.marketing,
        version: data.version || '',
        ts: data.ts || 0,
      };
    } catch (e) {
      return null;
    }
  }

  function getStoredConsent() {
    return parseConsent(readCookie(COOKIE_NAME));
  }

  function saveConsent(next) {
    state = {
      necessary: true,
      functional: !!next.functional,
      analytics: !!next.analytics,
      marketing: !!next.marketing,
    };

    var payload = JSON.stringify({
      necessary: true,
      functional: state.functional,
      analytics: state.analytics,
      marketing: state.marketing,
      version: VERSION,
      ts: Date.now(),
    });

    writeCookie(COOKIE_NAME, payload, CONSENT_DAYS);

    try {
      localStorage.setItem(COOKIE_NAME, payload);
    } catch (e) {
      /* ignore */
    }

    publishConsent(true);
  }

  function publishConsent(fromUserAction) {
    window.AgentraConsent = window.AgentraConsent || {};
    window.AgentraConsent.get = function () {
      return {
        necessary: true,
        functional: !!state.functional,
        analytics: !!state.analytics,
        marketing: !!state.marketing,
      };
    };
    window.AgentraConsent.hasChoice = function () {
      return !!getStoredConsent();
    };
    window.AgentraConsent.openSettings = openPreferences;
    window.AgentraConsent.acceptAll = acceptAll;
    window.AgentraConsent.rejectOptional = rejectOptional;

    var detail = window.AgentraConsent.get();
    detail.fromUserAction = !!fromUserAction;

    document.documentElement.setAttribute('data-agentra-consent', '1');
    document.documentElement.setAttribute('data-agentra-analytics', detail.analytics ? '1' : '0');
    document.documentElement.setAttribute('data-agentra-marketing', detail.marketing ? '1' : '0');
    document.documentElement.setAttribute('data-agentra-functional', detail.functional ? '1' : '0');

    window.dispatchEvent(new CustomEvent('agentra:consent-updated', { detail: detail }));

    if (window.dataLayer && typeof window.dataLayer.push === 'function') {
      window.dataLayer.push({
        event: 'agentra_consent_update',
        agentra_consent: detail,
      });
    }
  }

  function escapeHtml(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function categoryRow(id, title, desc, locked) {
    if (id !== 'necessary') {
      if (id === 'functional' && cfg.enableFunctional === false) return '';
      if (id === 'analytics' && cfg.enableAnalytics === false) return '';
      if (id === 'marketing' && cfg.enableMarketing === false) return '';
    }

    var control = locked
      ? '<span class="agentra-cc-badge">' + escapeHtml(i18n.alwaysOn || 'Always on') + '</span>'
      : '<label class="agentra-cc-switch">' +
        '<input type="checkbox" data-cat="' +
        id +
        '" ' +
        (state[id] ? 'checked' : '') +
        '>' +
        '<span></span></label>';

    return (
      '<div class="agentra-cc-category">' +
      '<h3>' +
      escapeHtml(title) +
      '</h3>' +
      control +
      '<p>' +
      escapeHtml(desc) +
      '</p>' +
      '</div>'
    );
  }

  function buildMarkup() {
    var policy = cfg.policyUrl || 'https://agentraa.com/cookie-policy/';
    var privacy = cfg.privacyUrl || 'https://agentraa.com/privacy-policy/';

    root.innerHTML =
      '<div class="agentra-cc-overlay" data-agentra-overlay hidden></div>' +
      '<aside class="agentra-cc-banner" role="dialog" aria-modal="false" aria-labelledby="agentra-cc-title" data-agentra-banner hidden>' +
      '<p class="agentra-cc-banner__eyebrow">Agentra</p>' +
      '<h2 class="agentra-cc-banner__title" id="agentra-cc-title">' +
      escapeHtml(i18n.title || 'We use cookies') +
      '</h2>' +
      '<p class="agentra-cc-banner__text">' +
      escapeHtml(i18n.text || '') +
      '</p>' +
      '<p class="agentra-cc-banner__links">' +
      '<a href="' +
      escapeHtml(policy) +
      '">' +
      escapeHtml(i18n.learnMore || 'Cookie Policy') +
      '</a><span>·</span><a href="' +
      escapeHtml(privacy) +
      '">' +
      escapeHtml(i18n.privacyLink || 'Privacy Policy') +
      '</a></p>' +
      '<div class="agentra-cc-actions">' +
      '<button type="button" class="agentra-cc-btn agentra-cc-btn--primary" data-action="accept-all">' +
      escapeHtml(i18n.acceptAll || 'Accept all') +
      '</button>' +
      '<button type="button" class="agentra-cc-btn agentra-cc-btn--secondary" data-action="reject">' +
      escapeHtml(i18n.rejectOptional || 'Reject optional') +
      '</button>' +
      '<button type="button" class="agentra-cc-btn agentra-cc-btn--ghost" data-action="open-prefs">' +
      escapeHtml(i18n.cookieSettings || 'Cookie settings') +
      '</button>' +
      '</div></aside>' +
      '<div class="agentra-cc-modal" role="dialog" aria-modal="true" aria-labelledby="agentra-cc-prefs-title" data-agentra-modal hidden>' +
      '<div class="agentra-cc-modal__panel">' +
      '<div class="agentra-cc-modal__header">' +
      '<h2 id="agentra-cc-prefs-title">' +
      escapeHtml(i18n.preferencesTitle || 'Cookie preferences') +
      '</h2>' +
      '<button type="button" class="agentra-cc-modal__close" data-action="close-prefs" aria-label="' +
      escapeHtml(i18n.close || 'Close') +
      '">×</button>' +
      '</div>' +
      '<div class="agentra-cc-modal__body">' +
      '<p class="agentra-cc-modal__intro">' +
      escapeHtml(i18n.preferencesIntro || '') +
      '</p>' +
      categoryRow('necessary', i18n.necessaryTitle, i18n.necessaryDesc, true) +
      categoryRow('functional', i18n.functionalTitle, i18n.functionalDesc, false) +
      categoryRow('analytics', i18n.analyticsTitle, i18n.analyticsDesc, false) +
      categoryRow('marketing', i18n.marketingTitle, i18n.marketingDesc, false) +
      '</div>' +
      '<div class="agentra-cc-modal__footer">' +
      '<button type="button" class="agentra-cc-btn agentra-cc-btn--primary" data-action="save-prefs">' +
      escapeHtml(i18n.savePreferences || 'Save preferences') +
      '</button>' +
      '<button type="button" class="agentra-cc-btn agentra-cc-btn--secondary" data-action="accept-all">' +
      escapeHtml(i18n.acceptAll || 'Accept all') +
      '</button>' +
      '<button type="button" class="agentra-cc-btn agentra-cc-btn--ghost" data-action="reject">' +
      escapeHtml(i18n.rejectOptional || 'Reject optional') +
      '</button>' +
      '</div></div></div>' +
      '<button type="button" class="agentra-cc-fab" data-agentra-fab hidden>' +
      escapeHtml(i18n.reopenLabel || 'Cookie Settings') +
      '</button>';

    els.overlay = $('[data-agentra-overlay]', root);
    els.banner = $('[data-agentra-banner]', root);
    els.modal = $('[data-agentra-modal]', root);
    els.fab = $('[data-agentra-fab]', root);
  }

  function show(el) {
    if (!el) return;
    el.hidden = false;
    requestAnimationFrame(function () {
      el.classList.add('is-visible');
    });
  }

  function hide(el) {
    if (!el) return;
    el.classList.remove('is-visible');
    window.setTimeout(function () {
      if (!el.classList.contains('is-visible')) {
        el.hidden = true;
      }
    }, 240);
  }

  function showBanner() {
    show(els.banner);
    hide(els.fab);
  }

  function hideBanner() {
    hide(els.banner);
    show(els.fab);
  }

  function openPreferences() {
    syncToggles();
    show(els.overlay);
    show(els.modal);
    hide(els.banner);
    document.documentElement.style.overflow = 'hidden';
  }

  function closePreferences() {
    hide(els.overlay);
    hide(els.modal);
    document.documentElement.style.overflow = '';
    if (!getStoredConsent()) {
      showBanner();
    } else {
      show(els.fab);
    }
  }

  function syncToggles() {
    root.querySelectorAll('input[data-cat]').forEach(function (input) {
      var key = input.getAttribute('data-cat');
      input.checked = !!state[key];
    });
  }

  function readToggles() {
    var next = {
      necessary: true,
      functional: false,
      analytics: false,
      marketing: false,
    };
    root.querySelectorAll('input[data-cat]').forEach(function (input) {
      var key = input.getAttribute('data-cat');
      next[key] = !!input.checked;
    });
    return next;
  }

  function acceptAll() {
    saveConsent({
      functional: cfg.enableFunctional !== false,
      analytics: cfg.enableAnalytics !== false,
      marketing: cfg.enableMarketing !== false,
    });
    closePreferences();
    hideBanner();
  }

  function rejectOptional() {
    saveConsent({
      functional: false,
      analytics: false,
      marketing: false,
    });
    closePreferences();
    hideBanner();
  }

  function savePreferences() {
    saveConsent(readToggles());
    closePreferences();
    hideBanner();
  }

  function onClick(e) {
    var actionEl = e.target.closest('[data-action]');
    if (!actionEl || !root.contains(actionEl)) {
      // Floating reopen + shortcode / class triggers.
      if (e.target.closest('.agentra-cc-open-settings') || e.target.closest('[data-agentra-fab]')) {
        e.preventDefault();
        openPreferences();
      }
      return;
    }

    var action = actionEl.getAttribute('data-action');
    if (action === 'accept-all') acceptAll();
    if (action === 'reject') rejectOptional();
    if (action === 'open-prefs') openPreferences();
    if (action === 'close-prefs') closePreferences();
    if (action === 'save-prefs') savePreferences();
  }

  function onKeydown(e) {
    if (e.key === 'Escape' && els.modal && els.modal.classList.contains('is-visible')) {
      closePreferences();
    }
  }

  function init() {
    root = document.getElementById('agentra-cc-root');
    if (!root) return;

    root.hidden = false;
    root.removeAttribute('hidden');

    var stored = getStoredConsent();
    if (stored) {
      state.functional = !!stored.functional;
      state.analytics = !!stored.analytics;
      state.marketing = !!stored.marketing;
    }

    buildMarkup();
    document.addEventListener('click', onClick);
    document.addEventListener('keydown', onKeydown);

    if (els.overlay) {
      els.overlay.addEventListener('click', closePreferences);
    }

    publishConsent(false);

    if (!stored) {
      showBanner();
    } else {
      show(els.fab);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
