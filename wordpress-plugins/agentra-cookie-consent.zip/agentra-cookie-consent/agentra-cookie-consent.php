<?php
/**
 * Plugin Name:       Agentra Cookie Consent
 * Plugin URI:        https://agentraa.com/cookie-policy/
 * Description:       Cookie banner and preference centre styled for Agentra. Supports necessary, functional, analytics and marketing categories with reopenable Cookie Settings.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Agentra Technologies (Private) Limited
 * Author URI:        https://agentraa.com
 * License:           Proprietary
 * Text Domain:       agentra-cookie-consent
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AGENTRA_CC_VERSION', '1.0.0' );
define( 'AGENTRA_CC_FILE', __FILE__ );
define( 'AGENTRA_CC_PATH', plugin_dir_path( __FILE__ ) );
define( 'AGENTRA_CC_URL', plugin_dir_url( __FILE__ ) );

/**
 * Default plugin options.
 *
 * @return array
 */
function agentra_cc_default_options() {
	return array(
		'policy_url'         => 'https://agentraa.com/cookie-policy/',
		'privacy_url'        => 'https://agentraa.com/privacy-policy/',
		'banner_title'       => 'We use cookies',
		'banner_text'        => 'We use cookies and similar technologies to run our website, keep it secure and remember your preferences. Optional analytics and marketing cookies are used only if you allow them.',
		'enable_functional'  => 1,
		'enable_analytics'   => 1,
		'enable_marketing'   => 1,
		'consent_days'       => 180,
		'show_on_admin'      => 0,
	);
}

/**
 * Get merged plugin options.
 *
 * @return array
 */
function agentra_cc_get_options() {
	$saved = get_option( 'agentra_cc_options', array() );
	if ( ! is_array( $saved ) ) {
		$saved = array();
	}
	return wp_parse_args( $saved, agentra_cc_default_options() );
}

/**
 * Whether the banner should render on this request.
 *
 * @return bool
 */
function agentra_cc_should_render() {
	if ( is_feed() || wp_doing_ajax() || wp_doing_cron() ) {
		return false;
	}

	$options = agentra_cc_get_options();
	if ( is_admin() && empty( $options['show_on_admin'] ) ) {
		return false;
	}

	return true;
}

/**
 * Enqueue front-end assets.
 */
function agentra_cc_enqueue_assets() {
	if ( ! agentra_cc_should_render() ) {
		return;
	}

	$options = agentra_cc_get_options();

	wp_enqueue_style(
		'agentra-cookie-consent',
		AGENTRA_CC_URL . 'assets/css/banner.css',
		array(),
		AGENTRA_CC_VERSION
	);

	wp_enqueue_script(
		'agentra-cookie-consent',
		AGENTRA_CC_URL . 'assets/js/banner.js',
		array(),
		AGENTRA_CC_VERSION,
		true
	);

	wp_localize_script(
		'agentra-cookie-consent',
		'agentraCookieConsent',
		array(
			'cookieName'       => 'agentra_cookie_consent',
			'consentDays'      => max( 1, absint( $options['consent_days'] ) ),
			'version'          => AGENTRA_CC_VERSION,
			'policyUrl'        => esc_url( $options['policy_url'] ),
			'privacyUrl'       => esc_url( $options['privacy_url'] ),
			'enableFunctional' => ! empty( $options['enable_functional'] ),
			'enableAnalytics'  => ! empty( $options['enable_analytics'] ),
			'enableMarketing'  => ! empty( $options['enable_marketing'] ),
			'i18n'             => array(
				'title'              => $options['banner_title'],
				'text'               => $options['banner_text'],
				'acceptAll'          => __( 'Accept all', 'agentra-cookie-consent' ),
				'rejectOptional'     => __( 'Reject optional', 'agentra-cookie-consent' ),
				'cookieSettings'     => __( 'Cookie settings', 'agentra-cookie-consent' ),
				'savePreferences'    => __( 'Save preferences', 'agentra-cookie-consent' ),
				'close'              => __( 'Close', 'agentra-cookie-consent' ),
				'preferencesTitle'   => __( 'Cookie preferences', 'agentra-cookie-consent' ),
				'preferencesIntro'   => __( 'Choose which optional cookies Agentra may use. Strictly necessary cookies are always on because the site needs them to work.', 'agentra-cookie-consent' ),
				'necessaryTitle'     => __( 'Strictly necessary', 'agentra-cookie-consent' ),
				'necessaryDesc'      => __( 'Required for security, sign-in sessions, forms, cookie choices and core website features.', 'agentra-cookie-consent' ),
				'functionalTitle'    => __( 'Functional', 'agentra-cookie-consent' ),
				'functionalDesc'     => __( 'Remember optional interface, language and display preferences.', 'agentra-cookie-consent' ),
				'analyticsTitle'     => __( 'Analytics & performance', 'agentra-cookie-consent' ),
				'analyticsDesc'      => __( 'Help us understand usage, diagnose errors and improve performance.', 'agentra-cookie-consent' ),
				'marketingTitle'     => __( 'Marketing & advertising', 'agentra-cookie-consent' ),
				'marketingDesc'      => __( 'Measure campaigns, referrals and conversions when marketing tools are enabled.', 'agentra-cookie-consent' ),
				'alwaysOn'           => __( 'Always on', 'agentra-cookie-consent' ),
				'learnMore'          => __( 'Cookie Policy', 'agentra-cookie-consent' ),
				'privacyLink'        => __( 'Privacy Policy', 'agentra-cookie-consent' ),
				'reopenLabel'        => __( 'Cookie Settings', 'agentra-cookie-consent' ),
			),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'agentra_cc_enqueue_assets' );

/**
 * Output banner markup in the footer.
 */
function agentra_cc_render_markup() {
	if ( ! agentra_cc_should_render() ) {
		return;
	}
	?>
	<div id="agentra-cc-root" class="agentra-cc" hidden aria-live="polite"></div>
	<?php
}
add_action( 'wp_footer', 'agentra_cc_render_markup', 5 );

/**
 * Shortcode / HTML helper to reopen preferences.
 *
 * Usage: [agentra_cookie_settings]
 * Or any element with class "agentra-cc-open-settings"
 *
 * @param array $atts Shortcode attributes.
 * @return string
 */
function agentra_cc_settings_shortcode( $atts = array() ) {
	$atts = shortcode_atts(
		array(
			'label' => __( 'Cookie Settings', 'agentra-cookie-consent' ),
			'class' => '',
		),
		$atts,
		'agentra_cookie_settings'
	);

	$class = trim( 'agentra-cc-open-settings ' . $atts['class'] );

	return sprintf(
		'<button type="button" class="%1$s">%2$s</button>',
		esc_attr( $class ),
		esc_html( $atts['label'] )
	);
}
add_shortcode( 'agentra_cookie_settings', 'agentra_cc_settings_shortcode' );

/**
 * Register settings.
 */
function agentra_cc_register_settings() {
	register_setting(
		'agentra_cc_settings',
		'agentra_cc_options',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'agentra_cc_sanitize_options',
			'default'           => agentra_cc_default_options(),
		)
	);
}
add_action( 'admin_init', 'agentra_cc_register_settings' );

/**
 * Sanitize options.
 *
 * @param array $input Raw options.
 * @return array
 */
function agentra_cc_sanitize_options( $input ) {
	$defaults = agentra_cc_default_options();
	$output   = $defaults;

	if ( ! is_array( $input ) ) {
		return $output;
	}

	$output['policy_url']        = isset( $input['policy_url'] ) ? esc_url_raw( $input['policy_url'] ) : $defaults['policy_url'];
	$output['privacy_url']       = isset( $input['privacy_url'] ) ? esc_url_raw( $input['privacy_url'] ) : $defaults['privacy_url'];
	$output['banner_title']      = isset( $input['banner_title'] ) ? sanitize_text_field( $input['banner_title'] ) : $defaults['banner_title'];
	$output['banner_text']       = isset( $input['banner_text'] ) ? sanitize_textarea_field( $input['banner_text'] ) : $defaults['banner_text'];
	$output['enable_functional'] = empty( $input['enable_functional'] ) ? 0 : 1;
	$output['enable_analytics']  = empty( $input['enable_analytics'] ) ? 0 : 1;
	$output['enable_marketing']  = empty( $input['enable_marketing'] ) ? 0 : 1;
	$output['consent_days']      = isset( $input['consent_days'] ) ? max( 1, absint( $input['consent_days'] ) ) : $defaults['consent_days'];
	$output['show_on_admin']     = empty( $input['show_on_admin'] ) ? 0 : 1;

	return $output;
}

/**
 * Admin menu.
 */
function agentra_cc_admin_menu() {
	add_options_page(
		__( 'Agentra Cookie Consent', 'agentra-cookie-consent' ),
		__( 'Cookie Consent', 'agentra-cookie-consent' ),
		'manage_options',
		'agentra-cookie-consent',
		'agentra_cc_render_admin_page'
	);
}
add_action( 'admin_menu', 'agentra_cc_admin_menu' );

/**
 * Settings page markup.
 */
function agentra_cc_render_admin_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$options = agentra_cc_get_options();
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Agentra Cookie Consent', 'agentra-cookie-consent' ); ?></h1>
		<p><?php esc_html_e( 'Configure the cookie banner shown on your marketing site. Optional scripts should only load after consent — listen for the agentra:consent-updated browser event or check window.AgentraConsent.', 'agentra-cookie-consent' ); ?></p>

		<form method="post" action="options.php">
			<?php settings_fields( 'agentra_cc_settings' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="agentra_cc_banner_title"><?php esc_html_e( 'Banner title', 'agentra-cookie-consent' ); ?></label></th>
					<td><input name="agentra_cc_options[banner_title]" id="agentra_cc_banner_title" type="text" class="regular-text" value="<?php echo esc_attr( $options['banner_title'] ); ?>"></td>
				</tr>
				<tr>
					<th scope="row"><label for="agentra_cc_banner_text"><?php esc_html_e( 'Banner text', 'agentra-cookie-consent' ); ?></label></th>
					<td><textarea name="agentra_cc_options[banner_text]" id="agentra_cc_banner_text" class="large-text" rows="4"><?php echo esc_textarea( $options['banner_text'] ); ?></textarea></td>
				</tr>
				<tr>
					<th scope="row"><label for="agentra_cc_policy_url"><?php esc_html_e( 'Cookie Policy URL', 'agentra-cookie-consent' ); ?></label></th>
					<td><input name="agentra_cc_options[policy_url]" id="agentra_cc_policy_url" type="url" class="regular-text" value="<?php echo esc_attr( $options['policy_url'] ); ?>"></td>
				</tr>
				<tr>
					<th scope="row"><label for="agentra_cc_privacy_url"><?php esc_html_e( 'Privacy Policy URL', 'agentra-cookie-consent' ); ?></label></th>
					<td><input name="agentra_cc_options[privacy_url]" id="agentra_cc_privacy_url" type="url" class="regular-text" value="<?php echo esc_attr( $options['privacy_url'] ); ?>"></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Optional categories', 'agentra-cookie-consent' ); ?></th>
					<td>
						<label><input type="checkbox" name="agentra_cc_options[enable_functional]" value="1" <?php checked( ! empty( $options['enable_functional'] ) ); ?>> <?php esc_html_e( 'Functional', 'agentra-cookie-consent' ); ?></label><br>
						<label><input type="checkbox" name="agentra_cc_options[enable_analytics]" value="1" <?php checked( ! empty( $options['enable_analytics'] ) ); ?>> <?php esc_html_e( 'Analytics & performance', 'agentra-cookie-consent' ); ?></label><br>
						<label><input type="checkbox" name="agentra_cc_options[enable_marketing]" value="1" <?php checked( ! empty( $options['enable_marketing'] ) ); ?>> <?php esc_html_e( 'Marketing & advertising', 'agentra-cookie-consent' ); ?></label>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="agentra_cc_consent_days"><?php esc_html_e( 'Remember consent (days)', 'agentra-cookie-consent' ); ?></label></th>
					<td><input name="agentra_cc_options[consent_days]" id="agentra_cc_consent_days" type="number" min="1" max="730" value="<?php echo esc_attr( $options['consent_days'] ); ?>"></td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>

		<hr>
		<h2><?php esc_html_e( 'Footer / reopen link', 'agentra-cookie-consent' ); ?></h2>
		<p><?php esc_html_e( 'Add this shortcode anywhere (footer recommended):', 'agentra-cookie-consent' ); ?></p>
		<code>[agentra_cookie_settings]</code>
		<p><?php esc_html_e( 'Or give any button/link the class:', 'agentra-cookie-consent' ); ?> <code>agentra-cc-open-settings</code></p>

		<h2><?php esc_html_e( 'Developer hook', 'agentra-cookie-consent' ); ?></h2>
		<pre style="background:#f6f7f7;padding:12px;overflow:auto;">window.addEventListener('agentra:consent-updated', function (event) {
  var consent = event.detail; // { necessary, functional, analytics, marketing }
  if (consent.analytics) {
    // load analytics
  }
});

// Current state:
// window.AgentraConsent.get()
</pre>
	</div>
	<?php
}

/**
 * Settings link on Plugins page.
 *
 * @param array $links Existing links.
 * @return array
 */
function agentra_cc_plugin_action_links( $links ) {
	$url = admin_url( 'options-general.php?page=agentra-cookie-consent' );
	array_unshift( $links, '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Settings', 'agentra-cookie-consent' ) . '</a>' );
	return $links;
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'agentra_cc_plugin_action_links' );
